package net.csdn.blog.chaijunkun.validation.group;

/**
 * 学生验证分组
 * @author chaijunkun
 * @since 2015年4月3日
 */
public interface StudentGroup {
	
	public static interface Add{}
	
	public static interface Del{}
	
	public static interface Get{}
	
	public static interface Update{}

}
